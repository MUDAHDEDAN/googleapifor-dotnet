This directory contains template files used when generating documentation with docfx.
