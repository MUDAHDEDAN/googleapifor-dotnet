# $title

This is the [API reference documentation](obj/api/$entry_namespace.yml) for $title.

For source code, please visit the [GitHub
repository](https://github.com/googleapis/google-api-dotnet-client).
